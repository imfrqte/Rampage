const assert=require('node:assert/strict');
const data=require('../dist/catalog.js');
const {find}=require('../dist/matcher.js');
const base={city:'Алматы',date:'2026-09-30',format:'corporate',category:'host',budget:250000};
assert.deepEqual(find(base,data).matches.map(x=>x.provider.name),['Арман Серик','Дана Алиева']);
assert.equal(find({...base,budget:180000},data).matches.length,1);
assert.equal(find({...base,budget:179999},data).matches.length,0);
assert.equal(find({...base,budget:100000},data).minimumPrice,180000);
assert.deepEqual(find({...base,date:'2026-10-10'},data).matches.map(x=>x.provider.name),['Дана Алиева']);
assert.equal(find({...base,date:'2028-01-01'},data).matches.length,0);
assert.equal(find({...base,format:'wedding',budget:400000},data).matches.length,3);
assert.throws(()=>find({...base,date:'2026-02-30'},data));
assert.throws(()=>find({...base,budget:NaN},data));
assert.throws(()=>find({...base,budget:0},data));
assert.throws(()=>find({...base,format:'toString'},data));
assert.throws(()=>find({...base,city:'Неизвестный'},data));
const unknownPrice={...data,catalog:[{...data.catalog[0],price:null}]};
assert.equal(find(base,unknownPrice).counts.unknownPrice,1);
assert.equal(find(base,unknownPrice).matches.length,0);
const fromPrice={...data,catalog:[{...data.catalog[0],priceType:'from'}]};
assert.equal(find(base,fromPrice).matches.length,0);
const expanded={...data,catalog:Array.from({length:6},(_,i)=>({...data.catalog[0],id:`fixture-${i}`,price:180000+i}))};
assert.equal(find(base,expanded).matches.length,3);
assert.equal(find(base,expanded).totalMatches,6);
let scenarios=0;
for(const city of data.cities)for(const category of Object.keys(data.categories))for(const format of Object.keys(data.formats))for(const budget of [1,150000,250000,400000])for(const date of ['2026-09-30','2026-10-10','2028-01-01']){
  const query={city,category,format,budget,date};
  const result=find(query,data);assert.ok(result.matches.length<=3);
  for(const {provider:p,saving} of result.matches){assert.equal(p.city,city);assert.equal(p.category,category);assert.ok(p.formats.includes(format));assert.ok(p.price<=budget);assert.equal(saving,budget-p.price);assert.equal(p.availability,'confirmed');assert.ok(!p.bookedDates.includes(date));assert.ok(date>=p.calendarFrom&&date<=p.calendarThrough);}
  scenarios++;
}
console.log(`PASS: core cases and ${scenarios} filter combinations`);
