const assert = require('node:assert/strict');
const ui = require('../dist/community-data.js');
const data = require('../dist/catalog.js');
for (const p of data.catalog) {
  const reviews = ui.demoReviews(p.id);
  assert.equal(reviews.length, 2);
  assert.equal(reviews.reduce((n,r)=>n+r.rating,0)/reviews.length,4.5);
  reviews.forEach(r=>{assert.equal(r.demo,true);assert.doesNotThrow(()=>ui.validateReview(r));});
  assert.equal(ui.avatar(p.id),ui.avatar(p.id));
  assert.ok(ui.avatar(p.id).startsWith('<svg'));
}
const valid = {firstName:'Алия',lastName:'Серикова',rating:5,text:'Всё понравилось, спасибо!',date:'2026-09-23'};
assert.deepEqual(ui.validateReview(valid),{...valid,demo:false});
for (const rating of [0,6,-1,2.5,NaN,'5']) assert.throws(()=>ui.validateReview({...valid,rating}));
for (const date of ['2026-02-30','invalid','2026-13-02']) assert.throws(()=>ui.validateReview({...valid,date}));
for (const firstName of ['','<img src=x>', 'a'.repeat(41)]) assert.throws(()=>ui.validateReview({...valid,firstName}));
assert.throws(()=>ui.validateReview({...valid,text:' short '}));
assert.throws(()=>ui.validateReview({...valid,text:'x'.repeat(1201)}));
assert.equal(ui.escapeHTML('<img src=x onerror="alert(1)">'),'&lt;img src=x onerror=&quot;alert(1)&quot;&gt;');
assert.ok(!ui.avatar('<script>').includes('<script>'));
console.log('PASS: 66 illustrated identities/demo review pairs; rating, date, name, length and HTML escaping boundaries.');
