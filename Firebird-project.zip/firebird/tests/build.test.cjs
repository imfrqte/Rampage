const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname,'../..');
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
assert.equal(html,fs.readFileSync(path.join(root,'Firebird.html'),'utf8'));
const refs = [...html.matchAll(/(?:href|src)="([^"?]+\.(?:css|js))\?v=([a-f0-9]{10})"/g)];
assert.equal(refs.length,11,'Four stylesheets and seven scripts must be present');
for (const [,filename,version] of refs) {
  const bytes = fs.readFileSync(path.join(root,filename));
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex').slice(0,10),version,filename);
}
const offline = fs.readFileSync(path.join(root,'Firebird-offline.html'),'utf8');
assert.ok(!/<script[^>]+src=|<link[^>]+rel="stylesheet"/.test(offline),'Offline edition must not depend on external CSS/JS');
assert.ok(offline.includes('id="bento-orbit"') && offline.includes('firebird:reviews:v1'));
console.log('PASS: published entry points, 11 versioned CSS/JS resources, and self-contained offline edition.');
