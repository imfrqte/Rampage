const assert=require('node:assert/strict');
const {performance}=require('node:perf_hooks');
const data=require('../dist/catalog.js');
const m=require('../dist/matcher.js');
const base={city:'Алматы',date:'2026-10-06',format:'корпоратив',category:'Ведущий',budget:1500000};
const ids=r=>r.matches.map(x=>x.provider.id);
assert.equal(data.catalog.length,66);
assert.equal(data.catalog.filter(p=>p.synthetic).length,13);
assert.equal(data.catalog.filter(p=>p.categories.includes('Ведущий')).length,15);
assert.equal(data.catalog.filter(p=>p.categories.includes('Фотограф')).length,12);
assert.equal(data.catalog.filter(p=>p.categories.includes('Банкетный зал')).length,8);
const dense=m.find(base,data);
assert.equal(dense.outcome,'matched');
assert.equal(dense.totalMatches,7);
assert.deepEqual(ids(dense),['HK-88430','HK-44733','HK-75012']);
assert.deepEqual(m.find(base,data),dense,'same request has same explanations and order');
assert.deepEqual(ids(m.find(base,{...data,catalog:[...data.catalog].reverse()})),ids(dense),'row order does not affect ranking');
const dateChanged=m.find({...base,date:'2026-10-07'},data);
assert.notDeepEqual(ids(dateChanged),ids(dense));
assert.ok(!ids(dateChanged).includes('HK-44733'));
assert.match(m.calendarChange(dense,dateChanged),/Буллма/);
assert.match(m.calendarChange(dense,dateChanged),/календаря/);
const rare=m.find({...base,date:'2026-10-04',format:'свадьба',category:'Флорист',budget:500000,hours:24},data);
assert.equal(rare.totalMatches,2,'null max_hours is not a limit');
assert.ok(rare.matches.every(x=>x.provider.max_hours===null));
assert.equal(m.find({...base,budget:0},data).outcome,'no_matches');
assert.equal(m.find({...base,city:'Астана',category:'Декоратор'},data).outcome,'no_category');
assert.equal(m.find({...base,date:'2026-12-26',budget:100000},data).outcome,'no_matches');
const venue=m.find({...base,date:'2026-11-14',format:'свадьба',category:'Банкетный зал',budget:6000000,hours:6},data);
assert.deepEqual(new Set(ids(venue)),new Set(['HK-90011','HK-64395']));
const one={...data,catalog:[{...data.catalog.find(p=>p.id==='HK-88430'),busy_dates:[],max_hours:6,price_from_kzt:500000}]};
assert.equal(m.find({...base,budget:500000,hours:6,language:'русский'},one).totalMatches,1);
assert.equal(m.find({...base,budget:499999},one).totalMatches,0);
assert.equal(m.find({...base,hours:6.5},one).counts.hours,1);
assert.equal(m.find({...base,language:'английский'},one).counts.language,1);
assert.equal(m.find(base,{...one,catalog:[{...one.catalog[0],price_from_kzt:null}]}).counts.priceUnknown,1);
assert.equal(m.find({...base,date:'2026-09-23'},one).totalMatches,1);
assert.equal(m.find({...base,date:'2026-12-31'},one).totalMatches,1);
for(const bad of [{date:'2026-09-22'},{date:'2027-01-01'},{date:'2026-02-30'},{budget:NaN},{budget:-1},{budget:0.5},{hours:0},{hours:25},{language:'немецкий'},{category:'toString'},{city:'Несуществующий город'}])assert.throws(()=>m.find({...base,...bad},data));
assert.equal(data.cities.length,91);
assert.equal(data.cityReference.cities.length,90);
for(const city of data.cities.filter(c=>!data.catalogCities.includes(c))){
  const r=m.find({...base,city},data);assert.equal(r.outcome,'no_category');assert.equal(r.poolSize,0);assert.equal(r.matches.length,0,'adding cities must not create providers');
}
let checked=0,maxMs=0;
// Independent filter oracle: all cities/categories/formats over four seasonal dates.
for(const city of data.catalogCities)for(const category of data.categories)for(const format of data.formats)for(const date of ['2026-09-23','2026-10-06','2026-11-14','2026-12-26']){
  const q={city,category,format,date,budget:1500000,language:'русский',hours:6};
  const start=performance.now(),r=m.find(q,data);maxMs=Math.max(maxMs,performance.now()-start);
  const pool=data.catalog.filter(p=>p.city===city&&p.categories.includes(category));
  const eligible=pool.filter(p=>!p.busy_dates.includes(date)&&p.event_formats.includes(format)&&Number.isFinite(p.price_from_kzt)&&p.price_from_kzt<=q.budget&&p.languages.includes(q.language)&&(p.max_hours===null||p.max_hours>=q.hours));
  assert.equal(r.totalMatches,eligible.length);
  assert.equal(r.matches.length,Math.min(3,eligible.length));
  assert.equal(r.excluded.length+eligible.length,pool.length);
  assert.equal(r.outcome,!pool.length?'no_category':!eligible.length?'no_matches':'matched');
  for(const match of r.matches){
    assert.ok(eligible.some(p=>p.id===match.provider.id));
    assert.ok(m.normalize(match.provider.description).includes(match.evidence.excerpt),'evidence is an exact source excerpt');
    assert.match(match.explanation,/цена от/);
    assert.ok(match.explanation.includes(date.split('-').reverse().join('.')));
  }
  checked++;
}
// Busy dates for each record, including multi-category venues, must never leak into results.
for(const p of data.catalog){
  const q={city:p.city,category:p.categories.at(-1),format:p.event_formats[0],date:p.busy_dates[0],budget:100000000};
  assert.ok(!ids(m.find(q,data)).includes(p.id));
}
// Evidence remains distinguishable after anonymized names are removed.
for(const r of [dense,rare,venue]){
  const excerpts=r.matches.map(x=>{let text=x.evidence.excerpt;for(const p of data.catalog)text=text.replaceAll(p.anon_name,'');return text;});
  assert.equal(new Set(excerpts).size,excerpts.length);
}
assert.ok(maxMs<10000);
console.log(`PASS: requirements, ${checked} cross-filter cases and busy-date checks for 66 records; max observed search ${maxMs.toFixed(2)} ms (local Node.js, not a browser SLA).`);
