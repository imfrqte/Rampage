"""Run with Python 3.10+: python tests/server_test.py. Uses an isolated temporary DB."""
import importlib.util
import io
import json
import os
import uuid
from contextlib import nullcontext
from http.cookies import SimpleCookie
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
test_root = Path(os.environ.get('FIREBIRD_TEST_TEMP', str(ROOT / '.runtime'))).resolve()
test_root.mkdir(parents=True, exist_ok=True)
with nullcontext(str(test_root / ('firebird-test-' + uuid.uuid4().hex))) as directory:
    Path(directory).mkdir()
    os.environ['FIREBIRD_DB'] = str(Path(directory) / 'test.sqlite3')
    os.environ['PUBLIC_ORIGIN'] = 'https://firebird.test'
    spec = importlib.util.spec_from_file_location('backend', ROOT / 'server' / 'app.py')
    app = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app)

    def request(path='/api/state', body=None, cookie='', origin='https://firebird.test'):
        raw = body if isinstance(body, bytes) else json.dumps(body).encode() if body is not None else b''
        env = {'PATH_INFO': path, 'REQUEST_METHOD': 'POST' if body is not None else 'GET',
               'CONTENT_LENGTH': str(len(raw)), 'CONTENT_TYPE': 'application/json',
               'HTTP_ORIGIN': origin, 'HTTP_X_FIREBIRD_REQUEST': '1', 'HTTP_COOKIE': cookie,
               'REMOTE_ADDR': '127.0.0.1', 'wsgi.input': io.BytesIO(raw)}
        response = {}
        def start(status, headers):
            response.update(status=int(status.split()[0]), headers=dict(headers))
        raw = b''.join(app.application(env, start))
        if response['headers']['Content-Type'].startswith('application/json'):
            response['json'] = json.loads(raw)
        response['raw'] = raw
        return response

    def action(name, p=None, cookie='', **extra):
        return request('/api/action', {'action': name, 'input': p or {}, **extra}, cookie)

    def cookie(response):
        value = response['headers']['Set-Cookie']
        assert 'HttpOnly' in value and 'SameSite=Lax' in value and 'Secure' in value
        return value.split(';')[0]

    def state(c=''):
        r = request(cookie=c)
        assert r['status'] == 200, r
        return r['json']

    assert state()['publicServices'] == []
    assert action('service')['status'] == 401
    a = cookie(action('register', dict(name='Тестовая команда A', role='provider', email='TEAM-A@example.test', password='Test-password-A-2026')))
    b = cookie(action('register', dict(name='Тестовая команда B', role='both', email='team-b@example.test', password='Test-password-B-2026')))
    assert state(a)['profile']['email'] == 'team-a@example.test'
    from PIL import Image
    photo = io.BytesIO()
    Image.new('RGB', (80, 120), (58, 110, 76)).save(photo, format='PNG')
    assert request('/api/avatar', photo.getvalue())['status'] == 401
    assert request('/api/avatar', b'<svg><script>alert(1)</script></svg>', a)['status'] == 400
    assert request('/api/avatar', photo.getvalue(), a, origin='https://evil.test')['status'] == 403
    assert request('/api/avatar', photo.getvalue(), a)['status'] == 200
    avatar_url = state(a)['profile']['avatar']
    assert avatar_url and not state(b)['profile']['avatar']
    avatar = request(avatar_url)
    assert avatar['headers']['Content-Type'] == 'image/jpeg'
    with Image.open(io.BytesIO(avatar['raw'])) as image:
        assert image.size == (400, 400) and len(image.getexif()) == 0
    assert action('register', dict(name='Дубль', role='provider', email='team-a@example.test', password='Test-password-A-2026'))['status'] == 409
    assert action('login', dict(email='team-a@example.test', password='Wrong-password-2026'))['status'] == 401
    service = dict(title='Тестовое ведение мероприятий', city='Шымкент', category='Ведущий', price=150000,
                   formats=['корпоратив'], description='Тестовое описание услуги для проверки публикации и доступа владельца.', website='https://example.com', status='draft')
    assert action('service', service, a)['status'] == 200
    own = state(a)['services'][0]
    assert state(b)['services'] == [] and state()['publicServices'] == []
    assert action('status', {'status': 'published'}, b, id=own['id'], revision=own['revision'])['status'] == 404
    assert action('status', {'status': 'published'}, a, id=own['id'], revision=999)['status'] == 409
    assert action('status', {'status': 'published'}, a, id=own['id'], revision=own['revision'])['status'] == 200
    visible = state()['publicServices'][0]
    assert visible['title'] == service['title'] and visible['city'] == 'Шымкент'
    assert 'email' not in visible and 'owner_id' not in visible
    assert action('service', service | {'website': 'javascript:alert(1)'}, a, id=own['id'], revision=visible['revision'])['status'] == 400
    assert action('service', service | {'price': True}, a)['status'] == 400
    assert action('service', service | {'formats': []}, a)['status'] == 400
    assert action('service', service | {'city': 'Несуществующий город'}, a)['status'] == 400
    assert action('favorite', cookie=a, id='HK-88430')['status'] == 200
    assert state(a)['favorites'] == ['HK-88430'] and state(b)['favorites'] == []
    q = dict(city='Кызылорда', date='2026-10-06', format='корпоратив', category='Ведущий', budget=150000, language='', hours=None)
    assert action('save-query', q, a)['status'] == 200
    assert action('save-query', q, a)['status'] == 200
    assert state(a)['searches'] == [q] and state(b)['searches'] == []
    assert request('/api/action', {'action': 'logout'}, a, origin='https://evil.test')['status'] == 403
    assert request('/../data/contractors.csv')['status'] == 404
    assert request('/.runtime/firebird.sqlite3')['status'] == 404
    assert request('/')['status'] == 200
    with app.db() as c:
        user = c.execute('SELECT * FROM users WHERE email=?', ('team-a@example.test',)).fetchone()
        assert user['password_hash'] != 'Test-password-A-2026' and len(user['salt']) == 32
        assert c.execute('SELECT digest FROM sessions LIMIT 1').fetchone()[0] not in a
    review = {'target': own['id'], 'rating': 5, 'text': 'Тестовый отзыв о работе команды.'}
    assert action('review', review)['status'] == 401
    assert action('review', review, a)['status'] == 403
    assert action('review', review | {'rating': True}, b)['status'] == 400
    assert action('review', review | {'rating': 6}, b)['status'] == 400
    assert action('review', review | {'target': 'missing'}, b)['status'] == 404
    assert action('review', review, b)['status'] == 200
    public = request('/api/reviews/' + own['id'])['json']
    assert public['count'] == 1 and public['average'] == 5 and not public['canReview']
    assert 'email' not in public['reviews'][0] and 'user_id' not in public['reviews'][0]
    assert action('review', review | {'rating': 3, 'text': '<script>alert(1)</script>'}, b)['status'] == 200
    updated = request('/api/reviews/' + own['id'], cookie=b)['json']
    assert updated['count'] == 1 and updated['average'] == 3 and updated['own']['rating'] == 3
    assert action('remove-review', {'target': own['id']}, b)['status'] == 200
    assert request('/api/reviews/' + own['id'])['json']['count'] == 0
    catalog_review = review | {'target': 'HK-88430'}
    assert action('review', catalog_review, a)['status'] == 200
    assert action('remove-review', catalog_review, b)['status'] == 200
    assert request('/api/reviews/HK-88430')['json']['count'] == 1
    assert action('review', catalog_review | {'rating': 3}, b)['status'] == 200
    assert request('/api/reviews/HK-88430')['json']['average'] == 4
    print('PASS: review authorization, self-review prevention, validation, upsert, owner-only deletion and aggregate ratings.')
    other_a = cookie(action('login', dict(email='team-a@example.test', password='Test-password-A-2026')))
    changed = action('password', {'current': 'Test-password-A-2026', 'replacement': 'Replacement-password-2026'}, a)
    assert changed['status'] == 200
    new_a = cookie(changed)
    assert not state(a)['opened'] and not state(other_a)['opened'] and state(new_a)['opened']
    assert state(new_a)['services'][0]['id'] == own['id']
    assert action('status', {'status': 'draft'}, new_a, id=own['id'], revision=visible['revision'])['status'] == 200
    assert state()['publicServices'] == []
    os.environ.pop('OPENAI_API_KEY', None)
    assert request('/api/assistant/status')['json']['enabled'] is False
    payload = {'message': 'Подбери ведущего', 'query': q, 'history': []}
    assert request('/api/assistant', payload, new_a)['status'] == 503
    os.environ['OPENAI_API_KEY'] = 'test-placeholder-no-network'
    assert request('/api/assistant', payload)['status'] == 401
    assert request('/api/assistant', payload, new_a, origin='https://evil.test')['status'] == 403
    assert request('/api/assistant', payload | {'query': None}, new_a)['status'] == 400
    captured = []
    def fake_model(body, key):
        captured.append(body)
        return {'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': json.dumps({'reply': 'Проверьте параметры.', 'query': q})}]}]}
    app.call_model = fake_model
    result = request('/api/assistant', payload, new_a)
    assert result['status'] == 200 and result['json']['query'] == q
    assert captured[0]['store'] is False and captured[0]['text']['format']['strict'] is True
    assert 'team-a@example.test' not in json.dumps(captured[0])
    app.call_model = lambda *_: {'output': []}
    assert request('/api/assistant', payload, new_a)['status'] == 502
    os.environ['OPENAI_DAILY_REQUEST_LIMIT'] = '1'
    assert request('/api/assistant', payload, new_a)['status'] == 429
    os.environ.pop('OPENAI_API_KEY')
    print('PASS: AI missing key, authentication, CSRF, validated structured output, privacy, refusal and quota (mocked API).')
    assert action('logout', cookie=new_a)['status'] == 200
    assert not state(new_a)['opened']
    assert len(app.CITIES) == 91
    print('PASS: accounts, private favorites, public services, owner checks, sessions, CSRF, 90 cities and validated 400px photo uploads with metadata removal.')
