const assert=require('node:assert/strict');const {matchCity}=require('../dist/location.js');const cities=require('../data/cities.json').cities;
assert.equal(matchCity({countryCode:'KZ',city:'Нур-Султан'},cities),'Астана');
assert.equal(matchCity({countryCode:'KZ',city:'Қызылорда'},cities),'Кызылорда');
assert.equal(matchCity({countryCode:'KZ',city:'город Алматы'},cities),'Алматы');
assert.equal(matchCity({countryCode:'US',city:'Алматы'},cities),null);
assert.equal(matchCity({countryCode:'KZ',city:'Неизвестный аул'},cities),null);
assert.equal(matchCity({countryCode:'KZ',city:'',locality:'Темиртау'},cities),'Темиртау');
console.log('PASS: geolocation city aliases, country boundary and unknown locality fallback.');
