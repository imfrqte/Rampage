"""Build the dependency-free app from the supplied CSV. Python standard library only."""
import csv
import hashlib
import json
from datetime import date
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'
SOURCE = ROOT / 'data' / 'contractors.csv'
START, END = '2026-09-23', '2026-12-31'
records = []
with SOURCE.open(encoding='utf-8-sig', newline='') as stream:
    for row in csv.DictReader(stream):
        for field in ('categories', 'event_formats', 'languages', 'busy_dates'):
            row[field] = row[field].split('|') if row[field] else []
        for field in ('synthetic', 'city_imputed', 'price_imputed'):
            assert row[field] in ('True', 'False'), (row['id'], field)
            row[field] = row[field] == 'True'
        row['price_from_kzt'] = int(row['price_from_kzt']) if row['price_from_kzt'] else None
        row['max_hours'] = int(row['max_hours']) if row['max_hours'] else None
        assert row['price_from_kzt'] is None or row['price_from_kzt'] >= 0
        assert row['max_hours'] is None or row['max_hours'] > 0
        for busy in row['busy_dates']:
            assert date.fromisoformat(busy).isoformat() == busy and START <= busy <= END
        records.append(row)
assert len({r['id'] for r in records}) == len(records)
city_reference = json.loads((ROOT / 'data' / 'cities.json').read_text(encoding='utf-8-sig'))
assert len(city_reference['cities']) == len(set(city_reference['cities'])) == 90
data = {
    'catalog': records,
    'cities': sorted(set(city_reference['cities']) | {r['city'] for r in records}),
    'catalogCities': sorted({r['city'] for r in records}),
    'cityReference': city_reference,
    'categories': sorted({c for r in records for c in r['categories']}),
    'formats': ['свадьба', 'той', 'корпоратив', 'конференция', 'юбилей', 'день рождения'],
    'languages': ['русский', 'казахский', 'английский'],
    'calendarFrom': START, 'calendarThrough': END,
    'source': {'filename': 'hackathon dataset anonymized .csv', 'sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest()},
}
serialized = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
(DIST / 'catalog.js').write_text("(function(root){'use strict';const data=" + serialized + ";if(typeof module!=='undefined'&&module.exports)module.exports=data;root.FirebirdData=data;})(globalThis);\n", encoding='utf-8')
html = (DIST / 'index.html').read_text(encoding='utf-8')
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + (DIST / 'styles.css').read_text(encoding='utf-8') + '\n</style>')
scripts = []
for name in ('catalog.js', 'matcher.js', 'app.js', 'member-store.js', 'members.js', 'assistant.js', 'reviews.js', 'location.js'):
    html = html.replace(f'  <script defer src="{name}"></script>\n', '')
    scripts.append('<script>\n' + (DIST / name).read_text(encoding='utf-8') + '\n</script>')
html = html.replace('</body>', '\n'.join(scripts) + '\n</body>').replace('href="./index.html"', 'href="#"')
(ROOT.parent / 'Firebird-server.html').write_text(html, encoding='utf-8')
for name in ('FIREBIRD-SERVER.md',):
    (ROOT.parent / name).write_text((ROOT / 'README.md').read_text(encoding='utf-8'), encoding='utf-8')
(ROOT.parent / 'FIREBIRD-DEPLOY.md').write_text((ROOT / 'DEPLOY.md').read_text(encoding='utf-8'), encoding='utf-8')
with zipfile.ZipFile(ROOT.parent / 'Firebird-server-project.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and '.runtime' not in path.parts and '.sqlite3' not in path.name and path.name != '.env':
            archive.write(path, Path('firebird') / path.relative_to(ROOT))
print(f'Built {len(records)} profiles; {sum(r["synthetic"] for r in records)} synthetic; CSV SHA256 {data["source"]["sha256"]}')
